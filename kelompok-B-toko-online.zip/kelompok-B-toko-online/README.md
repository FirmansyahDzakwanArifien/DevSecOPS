# STT-NF Toko Online — DevSecOps Lab (Kelompok B)

Aplikasi e-commerce sederhana yang mengandung beberapa kerentanan keamanan.

## Setup

```bash
docker-compose up -d
# Tunggu SonarQube di http://localhost:9000
sonar-scanner
```

## Struktur Utama
- `app/Http/Controllers/ProductController.php` — manajemen produk
- `app/Http/Controllers/CustomerController.php` — autentikasi pelanggan
- `app/Http/Controllers/InvoiceController.php` — invoice & laporan
- `config/database.php` — konfigurasi database
- `app/Http/Middleware/VerifyCsrfToken.php` — CSRF middleware
