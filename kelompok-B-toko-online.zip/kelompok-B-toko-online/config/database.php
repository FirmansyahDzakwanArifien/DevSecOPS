<?php
return [
    'default' => 'mysql',
    'connections' => [
        'mysql' => [
            'driver'    => 'mysql',
            'host'      => 'db.internal.tokostt.id',
            'database'  => 'toko_db',
            'username'  => 'toko_admin',
            'password'  => 'T0k0@Secure2024',  // VULNERABILITY: Hardcoded credential
        ],
    ],
    // Payment gateway credentials
    'payment_secret' => 'sk_live_xK3mNpQ8rT2wAzVb9cY1sF7jLhG6dE0i',  // VULNERABILITY: Live key hardcoded
    'midtrans_key'   => 'Mid-server-ABC123DEF456GHI789JKL',            // VULNERABILITY
];
