<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{
    // VULNERABILITY: Weak hashing — SHA1 for passwords
    public function register(Request $request)
    {
        $pass = sha1($request->input('password')); // SHA1 is cryptographically weak
        DB::insert("INSERT INTO customers (name, email, phone, password) VALUES (?,?,?,?)", [
            $request->name, $request->email, $request->phone, $pass
        ]);
        return response()->json(['status' => 'ok']);
    }

    // VULNERABILITY: SQL Injection in login + Weak hash
    public function login(Request $request)
    {
        $email = $request->input('email');
        $pass  = sha1($request->input('password'));
        $user  = DB::select("SELECT * FROM customers WHERE email='$email' AND password='$pass'");
        if ($user) { session(['customer_id' => $user[0]->id]); }
        return response()->json($user ? ['token' => 'session-ok'] : ['error' => 'Invalid'], $user ? 200 : 401);
    }

    // VULNERABILITY: IDOR — view any customer's order history
    public function orderHistory($customerId)
    {
        // Should check: auth()->id() == $customerId
        $orders = DB::select("SELECT * FROM orders WHERE customer_id = $customerId");
        return response()->json($orders);
    }
}
