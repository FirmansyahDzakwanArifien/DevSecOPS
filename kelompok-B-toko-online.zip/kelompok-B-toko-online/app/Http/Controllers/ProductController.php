<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    // VULNERABILITY: SQL Injection — search with raw query
    public function search(Request $request)
    {
        $name     = $request->input('name');
        $minPrice = $request->input('min_price', 0);
        $maxPrice = $request->input('max_price', 999999);
        // Dangerous: name directly concatenated
        $products = DB::select(
            "SELECT * FROM products WHERE name LIKE '%$name%'
             AND price BETWEEN $minPrice AND $maxPrice"
        );
        return response()->json($products);
    }

    // VULNERABILITY: SQL Injection — sort parameter not whitelisted
    public function listByCategory(Request $request)
    {
        $cat  = $request->input('category');
        $sort = $request->input('sort', 'name'); // attacker controls ORDER BY column
        $sql  = "SELECT * FROM products WHERE category='$cat' ORDER BY $sort";
        return response()->json(DB::select($sql));
    }

    // VULNERABILITY: IDOR — update any product without ownership check
    public function update(Request $request, $productId)
    {
        // No check: does this user own this product?
        DB::update("UPDATE products SET name=?, price=?, stock=? WHERE id=$productId", [
            $request->input('name'),
            $request->input('price'),
            $request->input('stock'),
        ]);
        return response()->json(['message' => 'Updated']);
    }

    // VULNERABILITY: Mass Assignment
    public function store(Request $request)
    {
        return response()->json(Product::create($request->all()));
    }
}
