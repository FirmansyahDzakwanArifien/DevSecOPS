<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    // VULNERABILITY: Path Traversal — download invoice by filename
    public function download(Request $request)
    {
        $invoiceFile = $request->input('invoice'); // e.g. "INV-2024-001.pdf"
        // Attacker: invoice=../../.env or invoice=../../../etc/shadow
        $path = storage_path('invoices/' . $invoiceFile);
        if (!file_exists($path)) abort(404);
        return response()->download($path);
    }

    // VULNERABILITY: Command Injection — PDF generation using user input
    public function generatePdf(Request $request)
    {
        $orderId  = $request->input('order_id');
        $template = $request->input('template', 'default');
        // Dangerous: template parameter is user-controlled
        $cmd    = "wkhtmltopdf --template $template /tmp/order_$orderId.html /tmp/inv_$orderId.pdf";
        $result = shell_exec($cmd);
        return response()->json(['file' => "/tmp/inv_$orderId.pdf"]);
    }

    // VULNERABILITY: Command Injection — export to Excel
    public function exportSales(Request $request)
    {
        $month = $request->input('month'); // "2024-01; cat /etc/passwd"
        exec("php artisan export:sales --month=" . $month, $output);
        return response()->json(['lines' => $output]);
    }
}
