<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    // VULNERABILITY: Mass Assignment
    protected $guarded = [];
    // Attacker can set: status='completed', total_price=1, user_id=<target>
}
