<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    // VULNERABILITY: Mass Assignment — no field restrictions
    protected $fillable = [];
    // Attacker can set: is_featured=1, price=0, stock=999999 via POST
}
