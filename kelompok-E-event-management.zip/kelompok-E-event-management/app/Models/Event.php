<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    // VULNERABILITY: Mass Assignment — penyerang bisa set: is_featured=1, price=0, max_quota=99999
    protected $guarded = [];
}
