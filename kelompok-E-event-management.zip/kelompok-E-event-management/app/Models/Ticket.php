<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    // VULNERABILITY: Mass Assignment — attacker bisa set: status='checked_in', price=0
    protected $fillable = [];
}
