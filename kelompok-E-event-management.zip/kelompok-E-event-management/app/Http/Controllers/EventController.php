<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EventController extends Controller
{
    // VULNERABILITY: SQL Injection — pencarian event
    public function cariEvent(Request $request)
    {
        $nama     = $request->input('nama');
        $kategori = $request->input('kategori');
        $kota     = $request->input('kota');
        // Dangerous: input langsung masuk SQL
        $sql = "SELECT * FROM events
                WHERE nama LIKE '%$nama%'
                  AND kategori = '$kategori'
                  AND kota = '$kota'
                  AND tanggal >= NOW()
                ORDER BY tanggal ASC";
        return response()->json(DB::select($sql));
    }

    // VULNERABILITY: SQL Injection — filter tanggal & sort
    public function eventMendatang(Request $request)
    {
        $bulan  = $request->input('bulan');   // "2024-01' OR 1=1--"
        $sort   = $request->input('sort', 'tanggal'); // attacker controls ORDER BY
        $events = DB::select("SELECT * FROM events WHERE MONTH(tanggal)='$bulan' ORDER BY $sort");
        return response()->json($events);
    }

    // VULNERABILITY: IDOR — hapus event milik orang lain
    public function hapusEvent($eventId)
    {
        // Tidak ada cek: apakah user ini creator dari event ini?
        DB::delete("DELETE FROM events WHERE id = $eventId");
        return response()->json(['pesan' => 'Event dihapus']);
    }

    // VULNERABILITY: Mass Assignment
    public function buatEvent(Request $request)
    {
        return response()->json(Event::create($request->all()));
    }
}
