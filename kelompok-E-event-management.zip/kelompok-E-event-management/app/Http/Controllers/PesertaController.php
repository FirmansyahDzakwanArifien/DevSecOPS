<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PesertaController extends Controller
{
    // VULNERABILITY: Weak hashing — MD5 untuk password peserta
    public function daftar(Request $request)
    {
        $password = md5($request->input('password')); // MD5 sangat lemah
        DB::insert("INSERT INTO peserta (nama, email, institusi, password)
                    VALUES (?, ?, ?, ?)", [
            $request->nama, $request->email, $request->institusi, $password
        ]);
        return response()->json(['status' => 'Registrasi berhasil, cek email Anda']);
    }

    // VULNERABILITY: SQL Injection + MD5 weak hash
    public function login(Request $request)
    {
        $email = $request->input('email');
        $pass  = md5($request->input('password')); // MD5 lemah
        $user  = DB::select("SELECT * FROM peserta WHERE email='$email' AND password='$pass'");
        if ($user) { session(['peserta_id' => $user[0]->id]); }
        return response()->json($user ? ['status' => 'Login berhasil'] : ['error' => 'Akun tidak ditemukan'], $user ? 200 : 401);
    }

    // VULNERABILITY: IDOR — lihat tiket peserta lain
    public function tiketPeserta($pesertaId)
    {
        // Harusnya: cek session peserta_id == $pesertaId
        $tiket = DB::select("SELECT * FROM tickets WHERE peserta_id = $pesertaId");
        return response()->json($tiket);
    }

    // VULNERABILITY: Mass Assignment — update profil peserta
    public function updateProfil(Request $request, $id)
    {
        // Attacker bisa set: is_vip=1, verified=1, role='admin'
        $peserta = DB::table('peserta')->where('id', $id)->update($request->all());
        return response()->json(['status' => 'Profil diperbarui']);
    }
}
