# STT-NF Event Management — DevSecOps Lab (Kelompok E)

Aplikasi manajemen event & tiket yang mengandung beberapa kerentanan keamanan.

## Setup

```bash
docker-compose up -d
# Tunggu SonarQube di http://localhost:9000
sonar-scanner
```

## Struktur Utama
- `app/Http/Controllers/EventController.php` — manajemen event
- `app/Http/Controllers/PesertaController.php` — registrasi peserta
- `app/Http/Controllers/OrganizerController.php` — tools organizer
- `config/database.php` — konfigurasi database
