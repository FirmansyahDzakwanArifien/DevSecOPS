<?php
return [
    'default' => 'mysql',
    'connections' => [
        'mysql' => [
            'driver'   => 'mysql',
            'host'     => 'event-db.stt-nf.ac.id',
            'database' => 'event_db',
            'username' => 'event_mgr',
            'password' => 'EventSys@2024!',  // VULNERABILITY: Hardcoded credential
        ],
    ],
    // Zoom & Stripe API
    'zoom_jwt_token'  => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.prod_zoom_token_stt_nf',  // VULNERABILITY
    'stripe_secret'   => 'sk_live_51JKm8fEventProdSecretKey0000000',                        // VULNERABILITY
    'whatsapp_token'  => 'EAAGX0UPprod_whatsapp_business_token_real',                      // VULNERABILITY
];
