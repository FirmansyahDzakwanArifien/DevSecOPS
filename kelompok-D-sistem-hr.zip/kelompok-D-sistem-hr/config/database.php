<?php
return [
    'default' => 'mysql',
    'connections' => [
        'mysql' => [
            'driver'   => 'mysql',
            'host'     => 'hr-db.stt-nf.internal',
            'database' => 'hr_system',
            'username' => 'hr_admin',
            'password' => 'HRSystem#Pass2024',  // VULNERABILITY: Hardcoded credential
        ],
    ],
    // Integrasi BPJS & pajak
    'bpjs_api_key'  => 'BPJS-PROD-KEY-8f2k4n7m9p3q',  // VULNERABILITY
    'pajak_secret'  => 'DJP-SECRET-TOKEN-xYz2024prod',  // VULNERABILITY
    'jwt_secret'    => 'jwt-super-secret-hr-system-2024',  // VULNERABILITY
];
