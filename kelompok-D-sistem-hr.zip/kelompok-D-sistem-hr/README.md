# STT-NF Sistem HR Kepegawaian — DevSecOps Lab (Kelompok D)

Aplikasi manajemen sumber daya manusia yang mengandung beberapa kerentanan keamanan.

## Setup

```bash
docker-compose up -d
# Tunggu SonarQube di http://localhost:9000
sonar-scanner
```

## Struktur Utama
- `app/Http/Controllers/KaryawanController.php` — manajemen karyawan
- `app/Http/Controllers/AuthHRController.php` — autentikasi HR
- `app/Http/Controllers/ToolsHRController.php` — tools & laporan
- `config/database.php` — konfigurasi database
