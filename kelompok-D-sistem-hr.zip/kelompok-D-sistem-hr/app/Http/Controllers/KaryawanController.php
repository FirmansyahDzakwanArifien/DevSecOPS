<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KaryawanController extends Controller
{
    // VULNERABILITY: SQL Injection — pencarian karyawan
    public function cariKaryawan(Request $request)
    {
        $nama      = $request->input('nama');
        $departemen = $request->input('departemen');
        $jabatan   = $request->input('jabatan');
        // Dangerous: parameter langsung masuk query
        $sql = "SELECT nik, nama, departemen, jabatan, status
                FROM karyawan
                WHERE nama LIKE '%$nama%'
                  AND departemen = '$departemen'
                  AND jabatan = '$jabatan'";
        return response()->json(DB::select($sql));
    }

    // VULNERABILITY: SQL Injection — filter periode
    public function laporanAbsensi(Request $request)
    {
        $nik    = $request->input('nik');
        $bulan  = $request->input('bulan');  // "2024-01' OR '1'='1"
        $result = DB::select("SELECT * FROM absensi WHERE nik='$nik' AND bulan='$bulan'");
        return response()->json($result);
    }

    // VULNERABILITY: IDOR — lihat data gaji karyawan lain
    public function detailGaji($karyawanId)
    {
        // Tidak ada cek: apakah yang login adalah karyawan ini atau HRD?
        $gaji = DB::select("SELECT * FROM penggajian WHERE karyawan_id = $karyawanId");
        return response()->json($gaji);
    }

    // VULNERABILITY: Mass Assignment
    public function updateDataKaryawan(Request $request, $id)
    {
        Karyawan::find($id)->update($request->all()); // bisa ubah gaji, is_manager, dll.
        return response()->json(['pesan' => 'Data diperbarui']);
    }
}
