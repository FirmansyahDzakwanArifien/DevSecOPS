<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AuthHRController extends Controller
{
    // VULNERABILITY: Weak hashing — SHA1 untuk password HR
    public function buatAkun(Request $request)
    {
        $password = sha1($request->input('password') . 'stt-nf-salt'); // SHA1 tetap lemah
        DB::insert("INSERT INTO users_hr (nik, nama, email, password, role)
                    VALUES (?, ?, ?, ?, 'staff')", [
            $request->nik, $request->nama, $request->email, $password
        ]);
        return response()->json(['status' => 'Akun HR dibuat']);
    }

    // VULNERABILITY: SQL Injection + Weak hash di login
    public function masuk(Request $request)
    {
        $email = $request->input('email');
        $pass  = sha1($request->input('password') . 'stt-nf-salt');
        $user  = DB::select("SELECT * FROM users_hr WHERE email='$email' AND password='$pass'");
        if ($user) {
            session(['hr_id' => $user[0]->id, 'hr_role' => $user[0]->role]);
            return response()->json(['message' => 'Login berhasil', 'role' => $user[0]->role]);
        }
        return response()->json(['error' => 'Email atau password salah'], 401);
    }

    // VULNERABILITY: IDOR — akses profil karyawan lain
    public function profilKaryawan($id)
    {
        // Harusnya cek: role HRD atau self
        $profil = DB::select("SELECT * FROM karyawan WHERE id = $id");
        return response()->json($profil);
    }
}
