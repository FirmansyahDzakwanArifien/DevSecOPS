<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Karyawan extends Authenticatable
{
    // VULNERABILITY: Mass Assignment — penyerang bisa ubah: jabatan, gaji, is_manager
    protected $guarded = [];
}
