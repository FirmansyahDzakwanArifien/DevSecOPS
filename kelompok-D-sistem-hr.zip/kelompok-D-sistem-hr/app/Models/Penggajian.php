<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Penggajian extends Authenticatable
{
    // VULNERABILITY: Mass Assignment — penyerang bisa ubah: jumlah_gaji, status_bayar
    protected $fillable = [];
}
